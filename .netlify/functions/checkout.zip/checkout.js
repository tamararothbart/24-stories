const crypto = require('crypto');

exports.handler = async function(event) {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: corsHeaders() };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: corsHeaders(), body: 'Method not allowed' };
  }

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch (e) {
    return { statusCode: 400, headers: corsHeaders(), body: JSON.stringify({ error: 'Invalid JSON' }) };
  }

  const {
    storytellerFirstName, storytellerSurname, storytellerEmail,
    storyHelperName, storyHelperEmail,
    giftGiverName, giftGiverEmail,
    familyEmails, phone,
    paymentType,  // 'monthly' or 'lump_sum'
    cancelUrl,    // optional: override the PayFast cancel destination
    notes         // optional: free-text context from the sign-up form
  } = body;

  if (!storytellerFirstName || !storytellerEmail) {
    return { statusCode: 400, headers: corsHeaders(), body: JSON.stringify({ error: 'Name and email required' }) };
  }

  const BASE = 'apprTOobuxs4Od7XB';
  const PAT  = process.env.AIRTABLE_PAT;

  // Create Pending subscriber record in Airtable
  const fields = {
    StorytellerFirstName: storytellerFirstName.trim(),
    StorytellerSurname:   (storytellerSurname  || '').trim(),
    StorytellerEmail:     storytellerEmail.trim().toLowerCase(),
    StoryHelperName:      (storyHelperName  || '').trim(),
    StoryHelperEmail:     (storyHelperEmail || '').trim().toLowerCase(),
    GiftGiverName:        (giftGiverName    || '').trim(),
    GiftGiverEmail:       (giftGiverEmail   || '').trim().toLowerCase(),
    FamilyEmails:         (familyEmails     || '').trim(),
    Phone:                (phone            || '').trim(),
    Status:               'Pending',
    PromptNumber:         0
  };

  Object.keys(fields).forEach(k => { if (fields[k] === '') delete fields[k]; });

  const atRes = await fetch(
    `https://api.airtable.com/v0/${BASE}/Subscribers`,
    {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${PAT}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ fields })
    }
  );

  if (!atRes.ok) {
    console.error('Airtable error:', await atRes.text());
    return { statusCode: 500, headers: corsHeaders(), body: JSON.stringify({ error: 'Could not save subscriber' }) };
  }

  const record   = await atRes.json();
  const recordId = record.id;

  // Build PayFast params
  // Send notes notification to Tamara if the sign-up form included context
  if (notes && notes.trim()) {
    const MJ_KEY    = process.env.MAILJET_API_KEY;
    const MJ_SECRET = process.env.MAILJET_API_SECRET;
    if (MJ_KEY && MJ_SECRET) {
      const mjAuth = Buffer.from(`${MJ_KEY}:${MJ_SECRET}`).toString('base64');
      const notifyName = giftGiverName || storytellerFirstName || 'New sign-up';
      await fetch('https://api.mailjet.com/v3.1/send', {
        method:  'POST',
        headers: { 'Authorization': `Basic ${mjAuth}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ Messages: [{ From: { Email: 'stories@24stories.co.za', Name: '24 Stories' }, To: [{ Email: 'hello@24stories.co.za', Name: '24 Stories' }], Subject: `SIGN-UP NOTES — ${notifyName}`, HTMLPart: `<p style="font-family:Georgia,serif;font-size:16px;line-height:1.8;color:#1A1A1A;"><strong>${notifyName}</strong> has started sign-up and left the following notes:</p><pre style="font-family:Georgia,serif;font-size:15px;line-height:1.8;color:#333;white-space:pre-wrap;">${notes.trim()}</pre><p style="font-family:Georgia,serif;font-size:14px;color:#888;margin-top:16px;">Storyteller email: ${storytellerEmail || '(not provided yet)'}</p>` }] })
      }).catch(err => console.error('Notes notification error:', err));
    }
  }

  const MERCHANT_ID  = process.env.PAYFAST_MERCHANT_ID  || '34556163';
  const MERCHANT_KEY = process.env.PAYFAST_MERCHANT_KEY || 'liduaqfvjfeox';
  const PASSPHRASE   = process.env.PAYFAST_PASSPHRASE   || '';
  const NOTIFY_URL   = 'https://24stories.co.za/.netlify/functions/payfast-webhook';
  const CANCEL_URL   = (cancelUrl && cancelUrl.trim()) ? cancelUrl.trim() : 'https://24stories.co.za/#subscribe';

  const isMonthly = (paymentType || 'monthly') === 'monthly';

  const params = {
    merchant_id:   MERCHANT_ID,
    merchant_key:  MERCHANT_KEY,
    return_url:    'https://24stories.co.za/thank-you.html',
    cancel_url:    CANCEL_URL,
    notify_url:    NOTIFY_URL,
    name_first:    storytellerFirstName.trim(),
    email_address: storytellerEmail.trim().toLowerCase(),
    m_payment_id:  recordId,
    amount:        isMonthly ? '2795.00' : '16770.00',
    item_name:     '24 Stories',
    custom_str1:   recordId,
    custom_str2:   isMonthly ? 'monthly' : 'lump_sum'
  };

  // Add subscription fields for monthly recurring
  if (isMonthly) {
    const today = new Date().toISOString().slice(0, 10);
    params.subscription_type   = '1';
    params.billing_date        = today;
    params.recurring_amount    = '2795.00';
    params.frequency           = '3';   // 3 = monthly
    params.cycles              = '6';   // auto-stop after 6 payments
  }

  // Generate MD5 signature
  const signature = generateSignature(params, PASSPHRASE);
  params.signature = signature;

  return {
    statusCode: 200,
    headers: corsHeaders(),
    body: JSON.stringify({ success: true, record_id: recordId, payfast_params: params })
  };
};

function generateSignature(params, passphrase) {
  // Build param string in key order, URL-encoded
  const str = Object.keys(params)
    .filter(k => k !== 'signature')
    .map(k => `${k}=${encodeURIComponent(String(params[k])).replace(/%20/g, '+')}`)
    .join('&');
  const withPhrase = passphrase ? `${str}&passphrase=${encodeURIComponent(passphrase).replace(/%20/g, '+')}` : str;
  return crypto.createHash('md5').update(withPhrase).digest('hex');
}

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };
}
